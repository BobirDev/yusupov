document.getElementById("navbar").onclick=function()
{
    var x, y, z, apple;
    x = Math.round(Math.random()*256);
    y = Math.round(Math.random()*256);
    z = Math.round(Math.random()*256);
    apple = 'rgb('+x+','+y+','+z+')';

    document.getElementById("navbar").style.backgroundColor = apple;
}
